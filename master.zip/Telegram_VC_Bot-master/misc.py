HELP_TEXT = """__**I Can Play Music In The Voice Chat**__

**/start** __To Start The bot.__
**/help** __To Show This Message.__
**/skip** __To Skip The Current Playing Music.__
**/play** __<youtube/saavn/deezer> <Song_Name>__
**/joinvc** __To Join A Voice Chat.__
**/leavevc** __To Leave A Voice Chat.__
**/telegram** __To Play From Telegram Audio.__

__**NOTE: Do Not Assign These Commands To Bot Via BotFather.**__"""

START_TEXT = "__**Hi I'm Telegram Voice Chat Bot. Join @PatheticProgrammers For Support.**__"

REPO_TEXT = "[Github](https://github.com/thehamkercat/Telegram_vc_bot)" \
            + " | [Group](t.me/PatheticProgrammers)"
